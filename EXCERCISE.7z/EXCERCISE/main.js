const fs = require('fs');

fs.readFile('input.txt', 'utf8', (err, input) => {
  if (err) {
    console.error(err);
    return;
  }

  const schedule = {};
  const employees = [];

  input.split('\n').forEach((line) => {
    const [name, scheduleData] = line.split('=');
    employees.push(name);
    schedule[name] = scheduleData.split(',').reduce((acc, time) => {
      acc[time.split('-')[0]] = true;
      return acc;
    }, {});
  });

  const result = {};
  for (let i = 0; i < employees.length; i++) {
    for (let j = i + 1; j < employees.length; j++) {
      const employee1 = employees[i];
      const employee2 = employees[j];
      let count = 0;
      Object.keys(schedule[employee1]).forEach((day) => {
        if (schedule[employee2][day]) {
          count++;
        }
      });
      result[`${employee1}-${employee2}`] = count;
    }
  }

  console.log(result);
});